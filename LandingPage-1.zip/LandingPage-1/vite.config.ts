import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          // Keep three.js out of the critical bundle so the page paints
          // before the hero scene finishes downloading.
          three: ['three', '@react-three/fiber'],
        },
      },
    },
  },
})
