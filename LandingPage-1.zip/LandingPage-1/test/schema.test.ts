import { describe, expect, it } from 'vitest'
import { registrationSchema } from '../src/lib/schema'
import { submitRegistration } from '../src/lib/submit'

const valid = {
  fullName: 'Alex Mercer',
  email: 'alex@example.com',
  country: 'IN',
  phone: '9876543210',
  demoId: 'NE-482913',
}

describe('registrationSchema', () => {
  it('accepts a valid entry', () => {
    expect(registrationSchema.safeParse(valid).success).toBe(true)
  })

  it('rejects a malformed email', () => {
    const r = registrationSchema.safeParse({ ...valid, email: 'alex@' })
    expect(r.success).toBe(false)
  })

  it('rejects a phone number that is invalid for the chosen country', () => {
    // Valid as an Indian number, impossible as a UK one.
    const r = registrationSchema.safeParse({ ...valid, country: 'GB' })
    expect(r.success).toBe(false)
    if (!r.success) {
      expect(r.error.issues.some((i) => i.path[0] === 'phone')).toBe(true)
    }
  })

  it('accepts the same number once the country matches', () => {
    const r = registrationSchema.safeParse({
      ...valid,
      country: 'GB',
      phone: '7400123456',
    })
    expect(r.success).toBe(true)
  })

  it('rejects a Demo ID containing punctuation', () => {
    expect(registrationSchema.safeParse({ ...valid, demoId: 'NE 4829!' }).success).toBe(
      false
    )
  })

  it('rejects a name made of digits', () => {
    expect(registrationSchema.safeParse({ ...valid, fullName: '12345' }).success).toBe(
      false
    )
  })
})

describe('submitRegistration', () => {
  it('resolves with an ok result the form can branch on', async () => {
    const res = await submitRegistration(valid)
    expect(res.ok).toBe(true)
  })
})
