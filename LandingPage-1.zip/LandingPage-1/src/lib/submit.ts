import type { Registration } from './schema'

export type SubmitResult = { ok: true } | { ok: false; error: string }

const STORAGE_KEY = 'gmcl:registrations'

/**
 * The single seam between the form and wherever registrations actually go.
 *
 * Right now it records locally so the full success/error UI is exercisable.
 * To go live, replace the body with your POST and keep the signature.
 *
 *   const res = await fetch(import.meta.env.VITE_REGISTER_URL, {
 *     method: 'POST',
 *     headers: { 'Content-Type': 'application/json' },
 *     body: JSON.stringify(data),
 *   })
 *   return res.ok ? { ok: true } : { ok: false, error: 'Registration failed.' }
 */
export async function submitRegistration(
  data: Registration
): Promise<SubmitResult> {
  await new Promise((r) => setTimeout(r, 900))

  try {
    const prev = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]')
    const next = Array.isArray(prev) ? prev : []
    next.push({ ...data, at: new Date().toISOString() })
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
  } catch {
    // Private browsing or a full quota. Not worth failing a registration over.
  }

  if (import.meta.env.DEV) console.info('[registration]', data)

  return { ok: true }
}
