import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

const vertex = /* glsl */ `
  varying vec3 vWorld;
  void main() {
    vec4 world = modelMatrix * vec4(position, 1.0);
    vWorld = world.xyz;
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`

const fragment = /* glsl */ `
  precision highp float;

  uniform float uTime;
  uniform float uScroll;
  uniform vec3  uColor;
  uniform float uFade;   // distance from camera at which the grid is gone

  varying vec3 vWorld;

  // Anti-aliased gridline mask with a width in SCREEN PIXELS.
  //
  // Dividing distance-to-line by fwidth converts to pixel units, which holds
  // a constant apparent thickness at every depth. Deriving the width from
  // fwidth alone leaves the lines sub-pixel here and they vanish entirely.
  float grid(vec2 coord, float px) {
    vec2 d = abs(fract(coord - 0.5) - 0.5) / max(fwidth(coord), vec2(1e-5));
    return 1.0 - min(min(d.x, d.y) / px, 1.0);
  }

  void main() {
    // Grid is laid out in world units, so the cell size is stable no matter
    // how the plane is scaled or positioned.
    vec2 world = vWorld.xz;

    // Drift toward the camera; page scroll adds to it so the floor keeps
    // flowing while the user moves down the hero.
    world.y -= uTime * 1.4 + uScroll * 40.0;

    float coarse = grid(world / 6.0, 1.7);
    float fine   = grid(world / 1.5, 1.0) * 0.28;
    float lines  = max(coarse, fine);

    // Fade against distance from the CAMERA, computed per fragment. A
    // per-vertex distance on a two-triangle quad interpolates to nonsense.
    float dCam = length(vWorld - cameraPosition);
    float fade = 1.0 - smoothstep(uFade * 0.10, uFade, dCam);
    fade = pow(fade, 1.5);

    // Slow bright band travelling outward from the origin, like a radar sweep.
    float ring = length(vWorld.xz);
    float pulse = smoothstep(0.6, 1.0, sin(ring * 0.06 - uTime * 0.7) * 0.5 + 0.5);

    float alpha = lines * fade * (0.30 + pulse * 0.85);

    // Haze pooling on the floor near the camera.
    float haze = fade * 0.035;

    vec3 col = uColor * (0.7 + pulse * 1.1);
    gl_FragColor = vec4(col, alpha + haze);
    if (gl_FragColor.a < 0.002) discard;
  }
`

export function GridShader({ size = 400, fade = 120 }: { size?: number; fade?: number }) {
  const mat = useRef<THREE.ShaderMaterial>(null)

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uScroll: { value: 0 },
      uColor: { value: new THREE.Color('#00ff87') },
      uFade: { value: fade },
    }),
    [fade]
  )

  useFrame((state) => {
    if (!mat.current) return
    mat.current.uniforms.uTime.value = state.clock.elapsedTime
    // Normalised against one viewport height  the hero is the only place
    // this material is visible, so that is the whole useful range.
    mat.current.uniforms.uScroll.value =
      window.scrollY / Math.max(window.innerHeight, 1)
  })

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -6, -40]}>
      <planeGeometry args={[size, size, 1, 1]} />
      <shaderMaterial
        ref={mat}
        uniforms={uniforms}
        vertexShader={vertex}
        fragmentShader={fragment}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  )
}
