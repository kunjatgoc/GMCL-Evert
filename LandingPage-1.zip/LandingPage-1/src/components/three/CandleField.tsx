import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

type Candle = {
  x: number
  z: number
  base: number
  amp: number
  speed: number
  phase: number
}

/**
 * Instanced candlestick columns.
 *
 * Split into two meshes rather than one, because `emissive` is a material
 * uniform  it cannot vary per instance. Two draw calls buys genuinely dark
 * candles sitting next to genuinely glowing ones, which is the entire effect.
 */
function useCandles(seedStart: number, count: number) {
  return useMemo<Candle[]>(() => {
    let seed = seedStart
    const rnd = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296
      return seed / 4294967296
    }
    return Array.from({ length: count }, () => {
      // Push every candle out of a corridor down the middle. Without this the
      // field grows straight through the headline, and no amount of vignette
      // rescues type sitting on top of moving geometry.
      const side = rnd() < 0.5 ? -1 : 1
      const corridor = 15
      return {
        x: side * (corridor + rnd() * 34),
        // Start well behind the camera plane so nothing looms at eye level.
        z: -32 - rnd() * 78,
        base: 1.4 + rnd() * 6.2,
        amp: 0.6 + rnd() * 2.4,
        speed: 0.25 + rnd() * 0.7,
        phase: rnd() * Math.PI * 2,
      }
    })
  }, [seedStart, count])
}

function Group({
  candles,
  material,
}: {
  candles: Candle[]
  material: React.ReactNode
}) {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const dummy = useMemo(() => new THREE.Object3D(), [])

  useFrame((state) => {
    const m = mesh.current
    if (!m) return
    const t = state.clock.elapsedTime
    for (let i = 0; i < candles.length; i++) {
      const c = candles[i]
      const h = c.base + Math.sin(t * c.speed + c.phase) * c.amp
      dummy.position.set(c.x, -6 + h / 2, c.z)
      dummy.scale.set(0.34, h, 0.34)
      dummy.updateMatrix()
      m.setMatrixAt(i, dummy.matrix)
    }
    m.instanceMatrix.needsUpdate = true
  })

  return (
    <instancedMesh
      ref={mesh}
      args={[undefined, undefined, candles.length]}
      frustumCulled={false}
    >
      <boxGeometry args={[1, 1, 1]} />
      {material}
    </instancedMesh>
  )
}

export function CandleField() {
  // Two seeds so the lit and unlit fields interleave instead of clustering.
  const lit = useCandles(20250907, 38)
  const dark = useCandles(20250918, 62)

  return (
    <>
      <Group
        candles={dark}
        material={
          <meshStandardMaterial
            color="#0c1f16"
            roughness={0.32}
            metalness={0.75}
          />
        }
      />
      <Group
        candles={lit}
        material={
          <meshStandardMaterial
            color="#00c853"
            emissive="#00ff87"
            emissiveIntensity={2.4}
            roughness={0.22}
            metalness={0.35}
            // ACES filmic rolls the emissive highlight off to a pale grey.
            // These bars are the accent  they should clip bright, not desaturate.
            toneMapped={false}
          />
        }
      />
    </>
  )
}
