import { Suspense, useEffect, useRef, useState } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'
import { GridShader } from './GridShader'
import { CandleField } from './CandleField'

/**
 * Damped mouse parallax plus a scroll-driven push down the corridor.
 * Everything is lerped  a hard follow feels like a bug, not a camera.
 */
function CameraRig() {
  const target = useRef({ x: 0, y: 0 })
  const { camera } = useThree()

  // Pointer is read off the window, not the canvas, so parallax keeps
  // responding while the cursor sits over the headline and CTA.
  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      target.current.x = (e.clientX / window.innerWidth) * 2 - 1
      target.current.y = -((e.clientY / window.innerHeight) * 2 - 1)
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => window.removeEventListener('pointermove', onMove)
  }, [])

  useFrame((_, delta) => {
    const p = target.current
    const scroll = window.scrollY / Math.max(window.innerHeight, 1)

    const wantX = p.x * 3.2
    const wantY = 1.5 + p.y * 1.6
    const wantZ = 16 - Math.min(scroll, 1) * 9

    // Frame-rate independent damping  a hard follow reads as a bug.
    const k = 1 - Math.pow(0.0015, delta)
    camera.position.x += (wantX - camera.position.x) * k
    camera.position.y += (wantY - camera.position.y) * k
    camera.position.z += (wantZ - camera.position.z) * k
    camera.lookAt(0, -1 + p.y * 1.2, -40)
  })

  return null
}

function Scene() {
  return (
    <>
      <color attach="background" args={['#0a0a0a']} />
      <fogExp2 attach="fog" args={['#040806', 0.021]} />

      <ambientLight intensity={0.35} />
      <directionalLight position={[8, 18, 6]} intensity={0.8} color="#bfffe0" />
      {/* Green key from below  the source of the ground glow. */}
      <pointLight position={[0, -4, -18]} intensity={140} distance={70} color="#00ff87" />
      <pointLight position={[-22, 6, -30]} intensity={90} distance={80} color="#00c853" />

      <GridShader />
      <CandleField />
      <CameraRig />
    </>
  )
}

export function HeroScene({ onFail }: { onFail: () => void }) {
  const [dead, setDead] = useState(false)
  if (dead) return null

  return (
    <Canvas
      className="!absolute inset-0"
      // Cap DPR: a 3x retina render of a full-bleed canvas is the single
      // biggest GPU cost here and is visually indistinguishable at 2x.
      dpr={[1, 2]}
      gl={{
        antialias: true,
        alpha: false,
        powerPreference: 'high-performance',
        toneMapping: THREE.ACESFilmicToneMapping,
      }}
      camera={{ position: [0, 1.5, 16], fov: 52, near: 0.1, far: 300 }}
      onCreated={({ gl }) => {
        gl.domElement.addEventListener('webglcontextlost', (e) => {
          e.preventDefault()
          setDead(true)
          onFail()
        })
      }}
    >
      <Suspense fallback={null}>
        <Scene />
      </Suspense>
    </Canvas>
  )
}
