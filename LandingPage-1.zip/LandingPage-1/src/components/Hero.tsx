import { lazy, Suspense, useState } from 'react'
import { motion } from 'motion/react'
import { ArrowDown, ShieldCheck } from 'lucide-react'
import { GlowButton } from './ui/GlowButton'
import { Eyebrow } from './ui/Eyebrow'
import { usePerfTier } from '../lib/usePerfTier'
import { EASE } from '../lib/motion'
import { scrollToId } from '../lib/scroll'

const HeroScene = lazy(() =>
  import('./three/HeroScene').then((m) => ({ default: m.HeroScene }))
)

const HEADLINE = [
  { text: 'Global Market', accent: false },
  { text: 'Champion League', accent: true },
]

/** Each line rises out from behind a hard mask, one after the other. */
function MaskedLine({
  children,
  delay,
}: {
  children: React.ReactNode
  delay: number
}) {
  return (
    <span className="block overflow-hidden pb-[0.12em]">
      <motion.span
        className="block"
        initial={{ y: '110%' }}
        animate={{ y: '0%' }}
        transition={{ duration: 1.05, ease: EASE, delay }}
      >
        {children}
      </motion.span>
    </span>
  )
}

/** Static plate shown on low-power devices, reduced motion, or context loss.
 *  This is what most phone traffic sees, so it carries the section on its own.
 *  When a generated plate is present it takes over; the CSS layers are the
 *  stand-in, not an overlay, or the two grids fight each other. */
function StaticPlate() {
  const [plate, setPlate] = useState<'pending' | 'loaded' | 'missing'>('pending')

  // Deterministic silhouette echoing the 3D candle field.
  const candles = Array.from({ length: 34 }, (_, i) => {
    const n = Math.sin(i * 12.9898) * 43758.5453
    const r = n - Math.floor(n)
    return { h: 8 + r * 62, lit: r > 0.62, delay: r * 3 }
  })

  return (
    <div className="absolute inset-0 overflow-hidden">
      <picture>
        <source media="(max-width: 768px)" srcSet="/img/hero-plate-mobile.webp" />
        <img
          src="/img/hero-plate.webp"
          alt=""
          aria-hidden
          fetchPriority="high"
          className="h-full w-full object-cover opacity-85"
          onLoad={() => setPlate('loaded')}
          onError={() => setPlate('missing')}
          style={{ display: plate === 'missing' ? 'none' : undefined }}
        />
      </picture>

      {/* Horizon bloom sits under both paths  it ties the plate into the
          page background regardless of which one is showing. */}
      <div
        aria-hidden
        className="absolute inset-0 [background:radial-gradient(88%_58%_at_50%_104%,rgba(0,255,135,0.30),rgba(0,200,83,0.08)_42%,transparent_66%)]"
      />

      {plate === 'missing' && (
        <>
          {/* Candle silhouette standing on the horizon. */}
          <div
            aria-hidden
            className="absolute inset-x-0 bottom-[26vh] flex items-end justify-center gap-[0.9vw] px-[4vw] opacity-70"
          >
            {candles.map((c, i) => (
              <span
                key={i}
                className="w-[0.7vw] max-w-[10px] rounded-[2px]"
                style={{
                  height: `${c.h}px`,
                  background: c.lit
                    ? 'linear-gradient(180deg,#00FF87,rgba(0,255,135,0.15))'
                    : 'linear-gradient(180deg,#123526,rgba(18,53,38,0.1))',
                  boxShadow: c.lit ? '0 0 14px rgba(0,255,135,0.55)' : 'none',
                  animation: `rail-pulse ${3 + c.delay}s ease-in-out infinite`,
                }}
              />
            ))}
          </div>

          {/* Perspective floor grid. */}
          <div
            aria-hidden
            className="absolute inset-x-0 bottom-0 h-[46vh] opacity-45 [transform:perspective(380px)_rotateX(64deg)] [transform-origin:bottom] [background-image:linear-gradient(rgba(0,255,135,0.65)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,135,0.65)_1px,transparent_1px)] [background-size:58px_58px] [mask-image:linear-gradient(to_top,#000_2%,transparent_78%)]"
          />

          <div
            aria-hidden
            className="absolute inset-x-0 bottom-[26vh] h-px bg-[linear-gradient(90deg,transparent,rgba(0,255,135,0.7),transparent)]"
          />
        </>
      )}
    </div>
  )
}

export function Hero() {
  const tier = usePerfTier()
  const [webglFailed, setWebglFailed] = useState(false)
  const use3D = tier === 'full' && !webglFailed

  const scrollToForm = () => scrollToId('register')

  return (
    <section
      className="grain relative isolate flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-6 pb-28 pt-32"
      aria-label="Global Market Champion League"
    >
      <div className="absolute inset-0 -z-20">
        {use3D ? (
          <Suspense fallback={<StaticPlate />}>
            <HeroScene onFail={() => setWebglFailed(true)} />
          </Suspense>
        ) : (
          <StaticPlate />
        )}
      </div>

      {/* Legibility scrim. Deliberately elliptical and capped well below
          opaque  a full-strength vignette buries the floor grid, which is
          the whole reason the scene is there. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(78%_56%_at_50%_46%,rgba(10,10,10,0.90)_0%,rgba(10,10,10,0.72)_44%,rgba(10,10,10,0.30)_68%,transparent_84%)]"
      />
      {/* Edge falloff only  corners and top, never the centre-bottom. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(135%_100%_at_50%_45%,transparent_55%,rgba(10,10,10,0.85)_100%)]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-40 bg-gradient-to-b from-[#0a0a0a] to-transparent"
      />
      {/* Blend the scene into the TrustBar below. */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-24 bg-gradient-to-t from-[#0a0a0a] to-transparent"
      />

      <div className="relative z-10 mx-auto flex w-full max-w-5xl flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE, delay: 0.1 }}
        >
          <Eyebrow>7 – 18 September · Registration open</Eyebrow>
        </motion.div>

        <h1 className="mt-8 text-[clamp(2.6rem,8.2vw,6.5rem)] font-bold leading-[0.94]">
          {HEADLINE.map((line, i) => (
            <MaskedLine key={line.text} delay={0.25 + i * 0.13}>
              <span className={line.accent ? 'text-[#00FF87] text-glow' : 'text-white'}>
                {line.text}
              </span>
            </MaskedLine>
          ))}
        </h1>

        <motion.p
          className="mt-8 max-w-2xl text-[clamp(1rem,1.9vw,1.2rem)] leading-relaxed text-[#9BA3A0]"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: EASE, delay: 0.62 }}
        >
          Think you can trade? Prove it. Enter the league, climb the board and
          win your share of{' '}
          <span className="font-semibold text-white">$175,000 in prizes</span>.
          Never traded before? Every fresher starts with a{' '}
          <span className="font-semibold text-white">$10,000 USD demo account</span>{' '}
           live market conditions, zero risk to your own money.
        </motion.p>

        <motion.div
          className="mt-11 flex flex-col items-center gap-5 sm:flex-row"
          initial={{ opacity: 0, y: 22 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, ease: EASE, delay: 0.78 }}
        >
          <GlowButton
            onClick={scrollToForm}
            className="animate-[breathe_3.4s_ease-in-out_infinite]"
          >
            Join the League
            <ArrowDown className="size-4 transition-transform duration-300 group-hover:translate-y-0.5" />
          </GlowButton>

          <span className="inline-flex items-center gap-2 text-sm text-[#9BA3A0] [text-shadow:0_1px_10px_rgba(0,0,0,0.9)]">
            <ShieldCheck className="size-4 text-[#00FF87]" />
            Free to enter · Demo capital only
          </span>
        </motion.div>
      </div>

      <motion.div
        aria-hidden
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
      >
        <div className="h-14 w-[1px] bg-gradient-to-b from-transparent via-[#00FF87]/70 to-transparent [animation:rail-pulse_2.4s_ease-in-out_infinite]" />
      </motion.div>
    </section>
  )
}
